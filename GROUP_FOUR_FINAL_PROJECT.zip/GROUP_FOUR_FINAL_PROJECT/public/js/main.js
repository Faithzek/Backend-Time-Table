document.addEventListener("DOMContentLoaded", () => {
  const timetableContainer = document.getElementById("timetable");
  const generateBtn = document.getElementById("generateBtn");
  const saveBtn = document.getElementById("saveBtn");

  generateBtn.addEventListener("click", generateTimetable);
  saveBtn.addEventListener("click", saveTimetable);

  loadTimetable();

  function loadTimetable() {
    fetch("/timetable")
      .then((response) => response.json())
      .then((timetable) => displayTimetable(timetable))
      .catch((error) => console.error("Error loading timetable:", error));
  }

  function generateTimetable() {
    fetch("/generate")
      .then((response) => response.json())
      .then((timetable) => displayTimetable(timetable))
      .catch((error) => console.error("Error generating timetable:", error));
  }

  function displayTimetable(timetable) {
    timetableContainer.innerHTML = "";
    const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];
    const table = document.createElement("table");

    const headerRow = table.insertRow();
    headerRow.insertCell().textContent = "DAYS OF THE WEEK";
    headerRow.insertCell().textContent = "7:00AM-8:00AM";
    headerRow.insertCell().textContent = "9:00AM-10:00AM";
    headerRow.insertCell().textContent = "11:00AM-12:00PM";
    headerRow.insertCell().textContent = "13:00PM-14:00PM";
    headerRow.insertCell().textContent = "15:00PM-16:00PM";
    headerRow.insertCell().textContent = "17:00PM-18:00PM";

    for (let day = 0; day < 5; day++) {
      const row = table.insertRow();
      row.insertCell().textContent = days[day];
      for (let hour = 0; hour < 6; hour++) {
        const cell = row.insertCell();
        const select = document.createElement("select");
        ["Arts", "Sports", "Sciences", "Languages"].forEach((subject) => {
          const option = document.createElement("option");
          option.value = option.textContent = subject;
          select.appendChild(option);
        });
        select.value = timetable[day][hour] || ""; // Handle undefined values.
        cell.appendChild(select);
      }
    }

    timetableContainer.appendChild(table);
  }

  function saveTimetable() {
    const timetable = [];
    const rows = timetableContainer.querySelectorAll("tr");

    for (let day = 1; day <= 5; day++) {
      timetable[day - 1] = [];
      for (let hour = 1; hour <= 6; hour++) {
        const select = rows[day].cells[hour].querySelector("select");
        timetable[day - 1][hour - 1] = select ? select.value : ""; // Handle undefined values
      }
    }

    fetch("/save", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(timetable),
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          alert("The Contents in the Time table have been Saved Successfully");
        } else {
          alert(
            "Hello, please recheck the Details, seems some Information is Mismatching"
          );
        }
      })
      .catch((error) => console.error("Error saving timetable:", error));
  }
});
